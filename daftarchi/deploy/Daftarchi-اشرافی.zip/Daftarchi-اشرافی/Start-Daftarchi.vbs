Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = root
env = shell.Environment("PROCESS")
env("DAFTARCHI_DATA") = root & "\data"
env("DAFTARCHI_CHANNEL") = "customer"
env("DAFTARCHI_PRESET") = root & "\preset.json"
env("DAFTARCHI_OPEN_BROWSER") = "1"
env("PORT") = "8080"
If Not fso.FolderExists(root & "\data") Then fso.CreateFolder root & "\data"
python = root & "\python\pythonw.exe"
If Not fso.FileExists(python) Then
  WScript.Quit 1
End If
shell.Run Chr(34) & python & Chr(34) & " " & Chr(34) & root & "\app\app.py" & Chr(34), 0, False
