<?php
/**
 * Minimal canvas shell for HTTP 404 — renders Elementor page 404-pm.
 */

defined( 'ABSPATH' ) || exit;

$page_id = PM_404::get_page_id();
if ( $page_id < 1 ) {
	return;
}

global $post, $wp_query;

$post = get_post( $page_id );
if ( ! $post instanceof WP_Post ) {
	return;
}

$wp_query->posts              = array( $post );
$wp_query->post               = $post;
$wp_query->post_count         = 1;
$wp_query->found_posts        = 1;
$wp_query->max_num_pages      = 1;
$wp_query->is_404             = true;
$wp_query->is_page            = true;
$wp_query->is_singular        = true;
$wp_query->queried_object     = $post;
$wp_query->queried_object_id  = $page_id;

setup_postdata( $post );
status_header( 404 );
nocache_headers();

?><!DOCTYPE html>
<html <?php language_attributes(); ?> dir="rtl">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex, follow">
	<?php wp_head(); ?>
</head>
<body <?php body_class( array( 'error404', 'pm-error-404', 'elementor-default' ) ); ?>>
<?php
if ( class_exists( '\Elementor\Plugin' ) ) {
	$elementor = \Elementor\Plugin::$instance;
	echo $elementor->frontend->get_builder_content_for_display( $page_id, true );
} else {
	echo wp_kses_post( apply_filters( 'the_content', $post->post_content ) );
}
wp_footer();
?>
</body>
</html>
